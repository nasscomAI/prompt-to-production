"""
UC-X: Ask My Documents
----------------------
A CLI-based document Q&A system that answers user questions
strictly from pre-loaded policy documents.

Usage:
    python app.py

    Then type your question at the prompt.
    Type 'exit' or 'quit' to stop.

CRAFT Loop:
    Iteration 1 — Fixed: cross-doc blending by enforcing single-source selection
    Iteration 2 — Fixed: hallucination by grounding answers to raw doc text only
    Iteration 3 — Fixed: missing citation by enforcing Source: line in every response
    Iteration 4 — Fixed: vague answers by extracting the most relevant paragraph
"""

import os
import re
import sys

# ── Configuration ──────────────────────────────────────────────────────────────

POLICY_DOCS_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "data", "policy-documents"
)

NO_ANSWER_TEXT = "I could not find an answer in the policy documents."

# ── Skill: load_documents ──────────────────────────────────────────────────────

def load_documents(docs_dir: str) -> list[dict]:
    """
    Load all .txt policy documents from the given directory.
    Returns a list of { 'filename': str, 'content': str } dicts.
    """
    documents = []
    if not os.path.isdir(docs_dir):
        print(f"[WARNING] Policy documents directory not found: {docs_dir}")
        return documents

    for fname in sorted(os.listdir(docs_dir)):
        if fname.endswith(".txt"):
            fpath = os.path.join(docs_dir, fname)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    content = f.read()
                documents.append({"filename": fname, "content": content})
            except Exception as e:
                print(f"[WARNING] Could not read {fname}: {e}")

    print(f"Loaded {len(documents)} document(s): {[d['filename'] for d in documents]}")
    return documents


# ── Skill: route_query ─────────────────────────────────────────────────────────

def tokenize(text: str) -> set[str]:
    """Lowercase word tokens, stripped of punctuation."""
    return set(re.findall(r"\b[a-z]{2,}\b", text.lower()))


# Tie-breaking priority: HR > Finance > IT
PRIORITY_ORDER = ["hr", "finance", "it"]

def doc_priority(filename: str) -> int:
    """Lower number = higher priority for tie-breaking."""
    fname_lower = filename.lower()
    for i, keyword in enumerate(PRIORITY_ORDER):
        if keyword in fname_lower:
            return i
    return len(PRIORITY_ORDER)


def route_query(question: str, documents: list[dict]) -> dict | None:
    """
    Select the single most relevant document for the question.
    Uses keyword overlap scoring. Returns None if no document matches.

    CRAFT fix: only ONE document selected — no cross-doc blending.
    """
    question_tokens = tokenize(question)
    best_doc = None
    best_score = 0

    for doc in documents:
        doc_tokens = tokenize(doc["content"])
        overlap = len(question_tokens & doc_tokens)
        score = overlap

        if score > best_score or (
            score == best_score
            and best_doc is not None
            and doc_priority(doc["filename"]) < doc_priority(best_doc["filename"])
        ):
            best_score = score
            best_doc = doc

    return best_doc if best_score > 0 else None


# ── Skill: extract_answer ──────────────────────────────────────────────────────

def extract_answer(question: str, document: dict) -> str:
    """
    Find the most relevant paragraph in the document and return it.

    CRAFT fix: answer is grounded strictly in document text.
    No external knowledge or inference added.
    """
    question_tokens = tokenize(question)

    # Split document into paragraphs (blank-line separated)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", document["content"]) if p.strip()]

    if not paragraphs:
        return NO_ANSWER_TEXT

    # Score each paragraph by token overlap with the question
    scored = []
    for para in paragraphs:
        para_tokens = tokenize(para)
        overlap = len(question_tokens & para_tokens)
        if overlap > 0:
            scored.append((overlap, para))

    if not scored:
        return NO_ANSWER_TEXT

    # Return the highest-scoring paragraph
    scored.sort(key=lambda x: x[0], reverse=True)
    best_para = scored[0][1]

    # Trim to a reasonable length (first 5 sentences)
    sentences = re.split(r"(?<=[.!?])\s+", best_para)
    answer = " ".join(sentences[:5])
    return answer


# ── Skill: format_response ─────────────────────────────────────────────────────

def format_response(answer: str, source_filename: str | None) -> str:
    """
    Format the final output with mandatory source citation.

    CRAFT fix: Source: line is always present — never omitted.
    """
    source = source_filename if source_filename else "N/A"
    return f"\nAnswer: {answer}\nSource: {source}\n"


# ── Main Loop ──────────────────────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("UC-X: Ask My Documents")
    print("Policy Q&A — Hyderabad | Nasscom AI Code Sarathi")
    print("=" * 60)
    print()

    # Skill: load_documents
    documents = load_documents(POLICY_DOCS_DIR)

    if not documents:
        print("[ERROR] No documents loaded. Please check the data/policy-documents/ directory.")
        sys.exit(1)

    print("\nType your question below. Type 'exit' to quit.\n")

    while True:
        try:
            question = input("Question: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not question:
            continue

        if question.lower() in ("exit", "quit"):
            print("Goodbye!")
            break

        # Skill: route_query — single source selection
        selected_doc = route_query(question, documents)

        if selected_doc is None:
            print(format_response(NO_ANSWER_TEXT, None))
            continue

        # Skill: extract_answer — grounded, no hallucination
        answer = extract_answer(question, selected_doc)

        # Skill: format_response — always cite source
        print(format_response(answer, selected_doc["filename"]))


if __name__ == "__main__":
    main()
