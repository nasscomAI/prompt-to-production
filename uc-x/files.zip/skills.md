# skills.md — UC-X: Ask My Documents

## Skill: load_documents
**Trigger:** On startup, before any query is processed
**Action:**
- Read all `.txt` files from `data/policy-documents/`
- Store each document as `{ filename: str, content: str }` in memory
- Print confirmation: `Loaded N documents.`

**Enforcement:**
- If a file is missing, print a warning and continue with available files
- Never silently skip a document

---

## Skill: route_query
**Trigger:** When a user question is received
**Action:**
- Score each loaded document for relevance to the question
- Use keyword overlap between question tokens and document content
- Select the single highest-scoring document
- If all scores are 0, return no-answer response

**Enforcement:**
- Only ONE document may be selected per query
- Do not merge or combine content from multiple documents
- Tie-breaking rule: prefer HR > Finance > IT when scores are equal

---

## Skill: extract_answer
**Trigger:** After `route_query` selects a source document
**Action:**
- Search the selected document for the most relevant paragraph or clause
- Extract a concise answer (2–5 sentences max) directly from the text
- Do not paraphrase beyond light grammatical cleanup
- Do not add external knowledge

**Enforcement:**
- Every word in the answer must traceable to the source document
- If relevant content is ambiguous, quote the exact clause

---

## Skill: format_response
**Trigger:** After `extract_answer` produces a result
**Action:**
- Print answer in the following format:

```
Answer: <answer text here>
Source: <filename>
```

- If no answer found, print:

```
Answer: I could not find an answer in the policy documents.
Source: N/A
```

**Enforcement:**
- Never omit the `Source:` line
- Never print a source that was not actually used

---

## Skill: craft_loop_validation
**Trigger:** During development / testing
**Action:**
- After each test query, verify:
  1. Was the correct document selected?
  2. Is the answer grounded (no hallucinated facts)?
  3. Is the source cited correctly?
  4. Is cross-doc blending absent?
- Log failures and apply fixes before next commit

**Enforcement:**
- A commit may only be made after all 4 checks pass for the test query
