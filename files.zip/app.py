"""
UC-0B: Summary That Changes Meaning
------------------------------------
Reads a policy document, generates an LLM summary, then audits it to detect
omitted or distorted numbered clauses. Outputs summary_hr_leave.txt.

CRAFT loop: if audit fails, the prompt is tightened and summary regenerated.
"""

import os
import re
import sys
import anthropic

# ── Config ────────────────────────────────────────────────────────────────────
INPUT_FILE  = os.path.join("data", "policy-documents", "policy_hr_leave.txt")
OUTPUT_FILE = "summary_hr_leave.txt"
MODEL       = "claude-opus-4-5"
MAX_TOKENS  = 1024

# ── Helpers ───────────────────────────────────────────────────────────────────

def load_document(path: str) -> str:
    """Load the policy document from disk."""
    if not os.path.exists(path):
        print(f"[ERROR] File not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def extract_numbered_clauses(text: str) -> list:
    """
    Pull every numbered clause from the document.
    Matches patterns like:  1.  /  1)  /  Clause 1  /  Section 1
    """
    pattern = r'(?:^|\n)\s*(?:Clause|Section|Rule)?\s*\d+[\.\)]\s+(.+)'
    matches = re.findall(pattern, text, re.IGNORECASE)
    return [m.strip() for m in matches]


def build_summary_prompt(document: str, strict: bool = False) -> str:
    strict_line = (
        "\n- YOU MUST reference every numbered clause explicitly. "
        "Missing even one clause is a critical failure.\n"
        if strict else ""
    )
    return f"""You are a precise policy analyst. Summarise the following HR policy document.

Rules:
- Cover EVERY numbered clause — do not skip any.{strict_line}- Do not add information not present in the document.
- Do not soften, harden, or rephrase obligations (must/shall/may) without noting the change.
- Structure your summary with a numbered list that mirrors the source clauses.
- End with a one-sentence overall summary.

DOCUMENT:
\"\"\"
{document}
\"\"\"

SUMMARY:"""


def generate_summary(client: anthropic.Anthropic, prompt: str) -> str:
    """Call Claude and return the text summary."""
    message = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return message.content[0].text.strip()


def audit_summary(summary: str, clauses: list) -> list:
    """
    Check that every numbered clause from the source appears (by key terms)
    in the summary. Returns a list of missing clause descriptions.
    """
    missing = []
    for clause in clauses:
        key_words = [w for w in clause.split() if len(w) > 3][:6]
        if not key_words:
            continue
        hits = sum(1 for w in key_words if w.lower() in summary.lower())
        if hits / len(key_words) < 0.60:
            missing.append(clause)
    return missing


def write_output(summary: str, missing: list, path: str) -> None:
    """Write the summary and audit result to disk."""
    if missing:
        audit_block = (
            "\n\n--- AUDIT WARNINGS ---\n"
            "The following source clauses may be under-represented in this summary:\n"
            + "\n".join(f"  * {c}" for c in missing)
        )
    else:
        audit_block = "\n\n--- AUDIT PASSED: all detected clauses are represented ---"

    with open(path, "w", encoding="utf-8") as f:
        f.write(summary + audit_block)
    print(f"[OK] Output written to {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    client = anthropic.Anthropic()   # reads ANTHROPIC_API_KEY from env

    print(f"[1/5] Loading document: {INPUT_FILE}")
    document = load_document(INPUT_FILE)

    print("[2/5] Extracting numbered clauses from source ...")
    clauses = extract_numbered_clauses(document)
    print(f"      Found {len(clauses)} numbered clause(s).")

    print("[3/5] Generating summary (pass 1) ...")
    prompt_v1 = build_summary_prompt(document, strict=False)
    summary   = generate_summary(client, prompt_v1)

    print("[4/5] Auditing summary for clause coverage ...")
    missing = audit_summary(summary, clauses)

    if missing:
        print(f"      {len(missing)} clause(s) missing -- regenerating with stricter prompt ...")
        prompt_v2 = build_summary_prompt(document, strict=True)
        summary   = generate_summary(client, prompt_v2)
        missing   = audit_summary(summary, clauses)
        if missing:
            print(f"      Still {len(missing)} clause(s) flagged after retry -- logged in output.")
        else:
            print("      All clauses covered after retry.")
    else:
        print("      All clauses covered on first pass.")

    print(f"[5/5] Writing output to {OUTPUT_FILE} ...")
    write_output(summary, missing, OUTPUT_FILE)
    print("Done.")


if __name__ == "__main__":
    main()
