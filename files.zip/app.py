"""
UC-0B: Summary That Changes Meaning
------------------------------------
Reads data/policy-documents/policy_hr_leave.txt, sends it to the
Claude API with a faithfulness-enforcing prompt, and writes the
output to uc-0b/summary_hr_leave.txt.

CRAFT loop is embedded as comments so the commit history reflects
each iteration of prompt refinement.

Usage:
    export ANTHROPIC_API_KEY=your_key_here
    python uc-0b/app.py
"""

import os
import sys
import anthropic

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT_FILE = os.path.join(BASE_DIR, "data", "policy-documents", "policy_hr_leave.txt")
OUTPUT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "summary_hr_leave.txt")

# ── Prompt ───────────────────────────────────────────────────────────────────
# CRAFT Iteration 3 — final enforced prompt
# Earlier iterations (see skills.md):
#   v1: plain "summarise in bullets"  → dropped clauses, softened modals
#   v2: added completeness rule       → fixed omissions, still softened modals
#   v3: added modal + exception rules → all five failure modes eliminated
SYSTEM_PROMPT = """You are a senior HR policy analyst. Your job is to summarise
policy documents faithfully and completely. You must never omit, soften, merge,
or reorder clauses.

STRICT RULES — violating any of these is a critical failure:
1. Every numbered clause in the source document MUST appear in your summary.
2. Modal verbs must be preserved exactly: "must" stays "must", "shall" stays "shall".
3. Every condition and exception must be explicitly stated (e.g. "except during probation").
4. Every numerical limit must be preserved exactly (e.g. "12 days", "3 months").
5. Do not add any information not present in the source.
6. Do not merge two clauses into one — each clause gets its own summary line.
7. Output format: numbered list matching source clause numbers."""

USER_PROMPT_TEMPLATE = """Summarise the following HR policy document faithfully.

<policy_document>
{policy_text}
</policy_document>

Produce a numbered summary. Each item must correspond to a clause in the source.
Start each item with the clause number from the source."""


def load_policy(path: str) -> str:
    """Read the policy document from disk."""
    if not os.path.exists(path):
        print(f"[ERROR] Policy file not found: {path}")
        print("  Make sure you have cloned the full repo including data/ folder.")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


def summarise(policy_text: str) -> str:
    """
    Send the policy text to Claude and return a faithful summary.

    Uses claude-haiku-3-5 for speed/cost efficiency.
    Swap to claude-sonnet-4-6 for higher accuracy if needed.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("[ERROR] ANTHROPIC_API_KEY environment variable is not set.")
        print("  Run: export ANTHROPIC_API_KEY=your_key_here")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    user_prompt = USER_PROMPT_TEMPLATE.format(policy_text=policy_text)

    print("[INFO] Sending policy document to Claude API...")
    message = client.messages.create(
        model="claude-haiku-4-5-20251001",   # fast + cost-effective for this task
        max_tokens=2048,
        system=SYSTEM_PROMPT,
        messages=[
            {"role": "user", "content": user_prompt}
        ]
    )

    # Extract the text from the response
    summary = message.content[0].text
    return summary


def validate_summary(policy_text: str, summary: str) -> list[str]:
    """
    Basic validation checks — warns if obvious failures are detected.
    Returns a list of warning strings (empty = all clear).
    """
    warnings = []

    # Check: modal verb softening
    import re
    must_count_source = len(re.findall(r'\bmust\b', policy_text, re.IGNORECASE))
    must_count_summary = len(re.findall(r'\bmust\b', summary, re.IGNORECASE))
    if must_count_source > 0 and must_count_summary < must_count_source // 2:
        warnings.append(
            f"WARN: Source has {must_count_source} 'must' occurrences, "
            f"summary has only {must_count_summary}. Possible modal softening."
        )

    # Check: exception keywords preserved
    for keyword in ["probation", "except", "unless", "not applicable"]:
        if keyword.lower() in policy_text.lower() and keyword.lower() not in summary.lower():
            warnings.append(f"WARN: Keyword '{keyword}' found in source but missing from summary.")

    return warnings


def save_summary(summary: str, path: str) -> None:
    """Write the summary to the output file."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("UC-0B: Faithful HR Leave Policy Summary\n")
        f.write("=" * 50 + "\n\n")
        f.write(summary)
        f.write("\n")
    print(f"[INFO] Summary written to: {path}")


def main():
    print("=" * 50)
    print("UC-0B: Summary That Changes Meaning")
    print("=" * 50)

    # Step 1 — Load
    print(f"[INFO] Loading policy from: {INPUT_FILE}")
    policy_text = load_policy(INPUT_FILE)
    print(f"[INFO] Loaded {len(policy_text)} characters.")

    # Step 2 — Summarise
    summary = summarise(policy_text)

    # Step 3 — Validate
    warnings = validate_summary(policy_text, summary)
    if warnings:
        print("\n[VALIDATION WARNINGS]")
        for w in warnings:
            print(f"  {w}")
        print("  Review the summary manually before committing.\n")
    else:
        print("[VALIDATION] All checks passed. ✓")

    # Step 4 — Save
    save_summary(summary, OUTPUT_FILE)

    print("\n[DONE] UC-0B complete.")
    print(f"  Output: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
