# skills.md — UC-0B: Summary That Changes Meaning

## Skill: FaithfulPolicySummariser

**Version:** 1.0  
**Used by:** PolicySummariserAgent (see agents.md)

---

## What This Skill Does

Takes raw policy document text and returns a faithful, clause-by-clause summary.  
Designed specifically to prevent the five failure modes listed in agents.md.

---

## Prompt Template

```
SYSTEM:
You are a senior HR policy analyst. Your job is to summarise policy documents
faithfully and completely. You must never omit, soften, merge, or reorder clauses.

STRICT RULES — violating any of these is a critical failure:
1. Every numbered clause in the source document MUST appear in your summary.
2. Modal verbs must be preserved exactly: "must" stays "must", "shall" stays "shall".
3. Every condition and exception must be explicitly stated (e.g. "except during probation").
4. Every numerical limit must be preserved exactly (e.g. "12 days", "3 months").
5. Do not add any information not present in the source.
6. Do not merge two clauses into one — each clause gets its own summary line.
7. Output format: numbered list matching source clause numbers.

USER:
Summarise the following HR policy document faithfully.

<policy_document>
{POLICY_TEXT}
</policy_document>

Produce a numbered summary. Each item must correspond to a clause in the source.
Start each item with the clause number from the source.
```

---

## CRAFT Loop — Prompt Refinement History

### Iteration 1 — Baseline prompt (what broke)
```
Prompt: "Summarise this HR leave policy in bullet points."
Failure: Dropped "not applicable during probation" clause entirely.
         Changed "must submit" to "should submit".
```

### Iteration 2 — Added completeness rule (partial fix)
```
Added: "Every numbered clause must appear in your summary."
Fix: Clause omission reduced.
Remaining failure: Still softened modal verbs.
```

### Iteration 3 — Added modal verb preservation rule (current)
```
Added: Modal verb rule + exception preservation rule.
Result: All five failure modes eliminated in test runs.
Commit: UC-0B Fix clause omission: completeness not enforced → added every-numbered-clause rule
```

---

## Validation Checklist (run after each summary)

- [ ] Count of summary items ≥ count of numbered clauses in source
- [ ] No "should" where source says "must"
- [ ] No "may" where source says "shall"
- [ ] All exceptions present (search for "except", "unless", "only if" in source)
- [ ] All numerical limits preserved
- [ ] No sentences added that aren't traceable to source

---

## Example: Good vs Bad Summary

**Source clause:**  
`5. Employees must submit a medical certificate for sick leave exceeding 2 consecutive days. This rule does not apply to employees on probation.`

**❌ Bad summary (failure):**  
`5. Employees should provide medical documentation for extended sick leave.`  
→ Softened "must" → "should", dropped the probation exception, dropped the "2 days" threshold.

**✅ Good summary (correct):**  
`5. Employees must submit a medical certificate for sick leave exceeding 2 consecutive days. This requirement does not apply to employees on probation.`
