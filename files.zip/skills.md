# skills.md — UC-0B: Summary That Changes Meaning

## Skill: PolicySummary

### Purpose
Summarise a numbered policy document faithfully, preserving every clause's
intent and modal obligation (must / shall / may / should).

---

### Input
```
document: str   — full text of the policy document
strict: bool    — if True, the prompt explicitly demands every clause be named
```

### Output
```
summary: str    — numbered list mirroring source clauses + one-sentence conclusion
```

---

### Prompt Template (standard)

```
You are a precise policy analyst. Summarise the following HR policy document.

Rules:
- Cover EVERY numbered clause — do not skip any.
- Do not add information not present in the document.
- Do not soften, harden, or rephrase obligations (must/shall/may) without noting the change.
- Structure your summary with a numbered list that mirrors the source clauses.
- End with a one-sentence overall summary.

DOCUMENT:
"""
{document}
"""

SUMMARY:
```

---

### Prompt Template (strict — used after audit failure)

Adds the following rule before the document block:

```
- YOU MUST reference every numbered clause explicitly.
  Missing even one clause is a critical failure.
```

---

## Skill: ClauseAudit

### Purpose
Compare source-document clauses against the generated summary to detect omissions.

### Algorithm
1. Extract numbered clauses from source using regex:
   `(?:^|\n)\s*(?:Clause|Section|Rule)?\s*\d+[\.\)]\s+(.+)`
2. For each clause, take its first 6 meaningful words (len > 3) as a fingerprint.
3. A clause is **present** if ≥ 60 % of its fingerprint words appear in the summary
   (case-insensitive).
4. Return list of clauses that fail the threshold.

### Thresholds
| Parameter | Value | Rationale |
|-----------|-------|-----------|
| Key-word length filter | > 3 chars | Excludes stopwords (the, and, is …) |
| Key-word sample size | 6 words | Enough signal, not too strict |
| Coverage threshold | 60 % | Allows paraphrasing; catches true omissions |

---

## Skill: OutputWriter

### Purpose
Write the final summary and audit result to `summary_hr_leave.txt`.

### Format
```
<numbered summary text>

--- AUDIT PASSED: all detected clauses are represented ---
```
or, on failure:
```
<numbered summary text>

--- AUDIT WARNINGS ---
The following source clauses may be under-represented in this summary:
  * <clause text>
  * <clause text>
```
