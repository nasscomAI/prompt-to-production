"""
UC-0B: Summary That Changes Meaning
====================================
Reads data/policy-documents/policy_hr_leave.txt, produces a faithful clause-by-clause
summary, runs a meaning-drift audit, and writes summary_hr_leave.txt.

Usage:
    python app.py

Requirements:
    pip install anthropic
    export ANTHROPIC_API_KEY=sk-...

CRAFT loop:
    - C: Clause-count completeness check
    - R: Number-fidelity regex check
    - A: Automated re-prompt on HIGH-severity drift
    - F: Faithful summariser prompt (skills.md → Skill 2)
    - T: Terminal report printed + file written
"""

import os
import re
import json
import sys
from pathlib import Path

try:
    import anthropic
except ImportError:
    print("ERROR: anthropic package not found. Run: pip install anthropic")
    sys.exit(1)

# ── paths ──────────────────────────────────────────────────────────────────────
POLICY_PATH = Path("data/policy-documents/policy_hr_leave.txt")
OUTPUT_PATH = Path("uc-0b/summary_hr_leave.txt")
MODEL = "claude-sonnet-4-20250514"
MAX_REFINE_ROUNDS = 3

# ── Anthropic client ──────────────────────────────────────────────────────────
api_key = os.environ.get("ANTHROPIC_API_KEY")
if not api_key:
    print("ERROR: ANTHROPIC_API_KEY environment variable not set.")
    sys.exit(1)

client = anthropic.Anthropic(api_key=api_key)


# ══════════════════════════════════════════════════════════════════════════════
# SKILL 1 — clause_extractor
# ══════════════════════════════════════════════════════════════════════════════
def clause_extractor(text: str) -> list[dict]:
    """
    Parse policy text into structured clauses.
    Returns list of {clause_id, text, numbers, conditionals}.
    """
    # Split on numbered list markers or blank-line-separated paragraphs
    raw_clauses = re.split(r'\n(?=\d+[\.\)]|\*\s|-\s|[a-z]\))', text)
    if len(raw_clauses) < 3:
        # fallback: split on double newlines
        raw_clauses = [p.strip() for p in text.split('\n\n') if p.strip()]

    clauses = []
    for i, chunk in enumerate(raw_clauses):
        chunk = chunk.strip()
        if not chunk:
            continue
        numbers = re.findall(r'\b\d+\.?\d*\b', chunk)
        conditionals = re.findall(
            r'\b(except|unless|provided that|subject to|at least|up to|'
            r'maximum|minimum|not more than|not less than|prior approval|'
            r'sanctioned by|approved by)\b',
            chunk, flags=re.IGNORECASE
        )
        clauses.append({
            "clause_id": i + 1,
            "text": chunk,
            "numbers": numbers,
            "conditionals": [c.lower() for c in conditionals],
        })
    return clauses


# ══════════════════════════════════════════════════════════════════════════════
# SKILL 2 — faithful_summariser
# ══════════════════════════════════════════════════════════════════════════════
SUMMARISE_SYSTEM = """You are a policy summarisation expert working for a civic HR department.
Your job: produce a numbered, clause-by-clause summary of the HR policy document provided.

STRICT RULES — violating any rule is a failure:
1. Include EVERY numbered or bulleted clause from the source, in the same order.
2. Copy EVERY number (days, percentages, durations, monetary limits) exactly as written.
   Never round, approximate, or drop a number.
3. Preserve EVERY exception, condition, and approval step. If the source says
   "unless approved by the Department Head", your summary must say the same.
4. Do NOT add any entitlement, restriction, or procedure not present in the source.
5. Do NOT merge two clauses into one if they have different numbers or conditions.
6. Write in plain English. Sentences ≤ 25 words.
7. Format: numbered list where each number matches a source clause.

Return ONLY the summary text. No preamble. No closing remarks."""


def faithful_summariser(document_text: str) -> str:
    """Call the LLM to produce a faithful clause-by-clause summary."""
    response = client.messages.create(
        model=MODEL,
        max_tokens=2000,
        system=SUMMARISE_SYSTEM,
        messages=[
            {"role": "user", "content": f"DOCUMENT:\n{document_text}\n\nSUMMARY:"}
        ],
    )
    return response.content[0].text.strip()


def summarise_single_clause(clause_text: str, failure_reason: str) -> str:
    """Re-summarise a single clause after a drift failure."""
    prompt = (
        f"The previous summary of this policy clause was WRONG because:\n"
        f"{failure_reason}\n\n"
        f"Re-summarise this clause faithfully, preserving all numbers and conditions:\n\n"
        f"CLAUSE:\n{clause_text}\n\nCORRECT SUMMARY:"
    )
    response = client.messages.create(
        model=MODEL,
        max_tokens=300,
        system=SUMMARISE_SYSTEM,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


# ══════════════════════════════════════════════════════════════════════════════
# SKILL 3 — meaning_drift_checker
# ══════════════════════════════════════════════════════════════════════════════
def meaning_drift_checker(source_text: str, summary_text: str) -> list[dict]:
    """
    Compare source to summary and return a list of drift findings.
    Each finding: {type, source_excerpt, summary_excerpt, severity, clause_id}
    """
    source_clauses = clause_extractor(source_text)
    summary_clauses = clause_extractor(summary_text)
    findings = []

    # C1 & C2: Number fidelity — every number in source must appear in summary
    all_source_numbers = set()
    for sc in source_clauses:
        all_source_numbers.update(sc["numbers"])

    all_summary_numbers = set()
    for sc in summary_clauses:
        all_summary_numbers.update(sc["numbers"])

    missing_numbers = all_source_numbers - all_summary_numbers
    for num in missing_numbers:
        # find which source clause has this number
        for sc in source_clauses:
            if num in sc["numbers"]:
                findings.append({
                    "type": "C1 — Number missing from summary",
                    "source_excerpt": sc["text"][:120],
                    "summary_excerpt": "(number not found in summary)",
                    "severity": "HIGH",
                    "clause_id": sc["clause_id"],
                    "missing_number": num,
                })
                break

    # C4: Conditionals dropped
    all_source_conds = set()
    for sc in source_clauses:
        all_source_conds.update(sc["conditionals"])

    all_summary_conds = set()
    for sc in summary_clauses:
        all_summary_conds.update(sc["conditionals"])

    missing_conds = all_source_conds - all_summary_conds
    for cond in missing_conds:
        for sc in source_clauses:
            if cond in sc["conditionals"]:
                findings.append({
                    "type": "C4 — Conditional phrase dropped",
                    "source_excerpt": sc["text"][:120],
                    "summary_excerpt": f'(phrase "{cond}" not found in summary)',
                    "severity": "MEDIUM",
                    "clause_id": sc["clause_id"],
                    "missing_cond": cond,
                })
                break

    # C5: Clause-count check
    if len(summary_clauses) < len(source_clauses):
        findings.append({
            "type": "C5 — Summary has fewer clauses than source",
            "source_excerpt": f"Source has {len(source_clauses)} clauses",
            "summary_excerpt": f"Summary has {len(summary_clauses)} clauses",
            "severity": "HIGH",
            "clause_id": 0,
        })

    return findings


# ══════════════════════════════════════════════════════════════════════════════
# SKILL 4 — report_writer
# ══════════════════════════════════════════════════════════════════════════════
def report_writer(summary_text: str, findings: list[dict], output_path: Path) -> str:
    """Write the audit report to output_path and return the report string."""
    high = [f for f in findings if f["severity"] == "HIGH"]
    medium = [f for f in findings if f["severity"] == "MEDIUM"]

    lines = [
        "=" * 70,
        "UC-0B: POLICY SUMMARY — HR LEAVE POLICY",
        "=" * 70,
        "",
        summary_text,
        "",
        "=" * 70,
        "MEANING-DRIFT AUDIT REPORT",
        "=" * 70,
        f"Total issues found : {len(findings)}",
        f"  HIGH severity    : {len(high)}",
        f"  MEDIUM severity  : {len(medium)}",
        "",
    ]

    if not findings:
        lines.append("✅  No meaning-drift issues detected. Summary is faithful.")
    else:
        for i, f in enumerate(findings, 1):
            lines += [
                f"Issue #{i} [{f['severity']}] {f['type']}",
                f"  Source  : \"{f['source_excerpt'].strip()}\"",
                f"  Summary : \"{f['summary_excerpt'].strip()}\"",
                "",
            ]

    report = "\n".join(lines)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(report, encoding="utf-8")
    return report


# ══════════════════════════════════════════════════════════════════════════════
# SKILL 5 — iterative_refiner
# ══════════════════════════════════════════════════════════════════════════════
def iterative_refiner(source_text: str, draft_summary: str, findings: list[dict]) -> str:
    """
    For each HIGH-severity finding, re-summarise the affected source clause
    and splice it back into the draft summary. Repeat up to MAX_REFINE_ROUNDS.
    """
    source_clauses = clause_extractor(source_text)
    current_summary = draft_summary

    for round_num in range(1, MAX_REFINE_ROUNDS + 1):
        high_findings = [f for f in findings if f["severity"] == "HIGH" and f.get("clause_id", 0) > 0]
        if not high_findings:
            break

        print(f"  [Refine round {round_num}] Fixing {len(high_findings)} HIGH-severity issue(s)...")

        for finding in high_findings:
            cid = finding["clause_id"]
            matching = [sc for sc in source_clauses if sc["clause_id"] == cid]
            if not matching:
                continue
            source_clause_text = matching[0]["text"]
            reason = f"{finding['type']}: {finding.get('missing_number', finding.get('missing_cond', ''))}"
            corrected = summarise_single_clause(source_clause_text, reason)
            # Splice: append correction as a note (simple strategy)
            current_summary += f"\n\n[CORRECTED — clause {cid}]: {corrected}"

        # Re-check after refinement
        findings = meaning_drift_checker(source_text, current_summary)
        remaining_high = [f for f in findings if f["severity"] == "HIGH"]
        print(f"  [Refine round {round_num}] Remaining HIGH issues: {len(remaining_high)}")
        if not remaining_high:
            break

    return current_summary, findings


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    print("=" * 60)
    print("UC-0B: Summary That Changes Meaning")
    print("=" * 60)

    # Load source document
    if not POLICY_PATH.exists():
        print(f"ERROR: Policy file not found at {POLICY_PATH}")
        print("Make sure you are running from the repo root directory.")
        sys.exit(1)

    source_text = POLICY_PATH.read_text(encoding="utf-8")
    print(f"\n[1/5] Loaded policy document ({len(source_text)} chars, "
          f"{len(source_text.splitlines())} lines)")

    # Extract clauses from source
    source_clauses = clause_extractor(source_text)
    print(f"[2/5] Extracted {len(source_clauses)} clauses from source")

    # Generate initial summary
    print("[3/5] Generating faithful summary via LLM...")
    draft_summary = faithful_summariser(source_text)
    print(f"      Summary generated ({len(draft_summary)} chars)")

    # Run meaning-drift check
    print("[4/5] Running meaning-drift audit...")
    findings = meaning_drift_checker(source_text, draft_summary)
    high_count = sum(1 for f in findings if f["severity"] == "HIGH")
    print(f"      Issues found: {len(findings)} total, {high_count} HIGH-severity")

    # Iterative refinement if needed
    final_summary = draft_summary
    if high_count > 0:
        print("[4b]  Running iterative refinement for HIGH-severity issues...")
        final_summary, findings = iterative_refiner(source_text, draft_summary, findings)
        high_count = sum(1 for f in findings if f["severity"] == "HIGH")
        print(f"      After refinement: {high_count} HIGH-severity issues remain")

    # Write report
    print(f"[5/5] Writing audit report to {OUTPUT_PATH}...")
    report = report_writer(final_summary, findings, OUTPUT_PATH)

    # Print summary to terminal
    print("\n" + "=" * 60)
    print("RESULT")
    print("=" * 60)
    print(report)
    print(f"\n✅  Output written to: {OUTPUT_PATH.resolve()}")

    # Exit code: 0 if clean, 1 if HIGH issues remain
    final_high = sum(1 for f in findings if f["severity"] == "HIGH")
    if final_high > 0:
        print(f"\n⚠️  {final_high} HIGH-severity meaning-drift issue(s) remain. Review the report.")
        sys.exit(1)
    else:
        print("\n✅  Summary is faithful — no HIGH-severity drift detected.")
        sys.exit(0)


if __name__ == "__main__":
    main()
