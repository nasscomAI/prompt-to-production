# UC-0B: Summary That Changes Meaning — skills.md

## Skill 1 — clause_extractor
**Purpose**: Parse a plain-text policy document and return every numbered/bulleted
clause as a structured list with its clause ID, full text, all numbers mentioned,
and any conditional phrases.

**Input**: Raw policy document text (string)
**Output**: List of dicts `{clause_id, text, numbers[], conditionals[]}`

**Steps**:
1. Split document on blank lines and on numbered-list markers (e.g., `1.`, `a.`, `-`).
2. For each segment, extract:
   - All integers and fractions (regex `\d+\.?\d*`)
   - All conditional phrases (regex for "except", "unless", "provided that",
     "subject to", "at least", "up to", "maximum", "minimum")
3. Return the structured list.

---

## Skill 2 — faithful_summariser
**Purpose**: Produce a clause-by-clause summary of a policy document that preserves
all numbers, entitlements, exceptions, and escalation paths.

**Input**: Raw policy document text (string)
**Output**: Summary text (string) with one paragraph per source clause

**Prompt template** (passed to LLM):
```
You are a policy summarisation expert.
Summarise the following HR policy document.
Rules:
- Include every numbered clause in the same order.
- Copy every number (days, percentages, durations) exactly as written.
- Preserve every exception, condition, and approval step word-for-word if needed.
- Do NOT add entitlements not present in the source.
- Do NOT drop any clause.
- Write in plain English, ≤ 25 words per sentence.
- Format: numbered list matching the source.

DOCUMENT:
{document_text}

SUMMARY:
```

---

## Skill 3 — meaning_drift_checker
**Purpose**: Compare the source document to the generated summary and flag any
cases where meaning has changed.

**Input**: `source_text` (str), `summary_text` (str)
**Output**: List of `{type, source_excerpt, summary_excerpt, severity}` dicts

**Checks performed**:

| Check ID | What it looks for | Severity |
|---|---|---|
| C1 | Numbers in source missing from summary | HIGH |
| C2 | Numbers changed (e.g., 21 → 20) | HIGH |
| C3 | Entitlement direction flipped ("up to 5" → "5") | HIGH |
| C4 | Conditional phrase dropped ("unless approved" missing) | MEDIUM |
| C5 | Clause present in source but absent from summary | HIGH |
| C6 | Entitlement added in summary not present in source | HIGH |

**Algorithm**:
1. Run `clause_extractor` on both source and summary.
2. For each source clause, find the best-matching summary clause (string similarity).
3. Compare numbers list — flag any mismatch (C1, C2).
4. Compare conditionals list — flag any missing conditional (C4).
5. Flag source clauses with no summary match (C5).
6. Flag summary clauses with no source match (C6).

---

## Skill 4 — report_writer
**Purpose**: Produce a human-readable audit report combining the summary and the
drift-check findings.

**Input**: `summary_text` (str), `drift_findings` (list of dicts)
**Output**: Formatted report (string) written to `summary_hr_leave.txt`

**Format**:
```
=== POLICY SUMMARY ===
{summary_text}

=== MEANING-DRIFT AUDIT ===
Total issues found: {N}

{for each finding}
[{severity}] {type}
  Source   : "{source_excerpt}"
  Summary  : "{summary_excerpt}"
```

---

## Skill 5 — iterative_refiner
**Purpose**: If `meaning_drift_checker` finds HIGH-severity issues, automatically
re-prompt the LLM with the flagged clauses and regenerate only those sections.

**Input**: `source_text`, `draft_summary`, `drift_findings`
**Output**: Refined summary text

**Steps**:
1. Filter findings where severity == "HIGH".
2. For each flagged clause, re-run `faithful_summariser` on that clause alone with
   an additional instruction: "The previous summary of this clause was wrong because:
   {finding description}. Fix it."
3. Splice the corrected clause back into the draft summary.
4. Re-run `meaning_drift_checker`. Repeat up to 3 times.
